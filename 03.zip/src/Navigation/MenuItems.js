export const MenuItems = [
  {
    title: 'User Sign In',
    path: '/signin',
    cName: 'dropdown-link'
  },
  {
    title: 'Institutional Sign In',
    path: '/adminSignin',
    cName: 'dropdown-link'
  }
 
];
